public class Game {
    public static void main(String[] args) {
        Prompter prompter = new Prompter();
        prompter.startGame();
        
    }
}
