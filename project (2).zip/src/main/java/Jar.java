
public class Jar {
  
    private String itemName;
    private int maxNum;

public Jar(String itemName, int maxNum) {
      this.itemName = itemName;
      this.maxNum = maxNum;
  }
  

  public String getItemName() {
      return itemName;
  }
  
  public int getMaxNum() {
      return maxNum;
  }
}